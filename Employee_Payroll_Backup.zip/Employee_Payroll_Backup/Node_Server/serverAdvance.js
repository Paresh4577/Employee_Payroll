const express = require("express");
const mongoose = require("mongoose");
const salarySchema = require("./SalarySchema");
const empSchema = require("./dataSchema");
const advanceSchema = require("./AdvanceSchema");
const cors = require('cors');

const app = express();
const conStr = "mongodb+srv://paresh_mori_67:Paresh%404577@paresh.xmqiuhh.mongodb.net/EmpDatabase";
const corsOptions = {
  origin: 'http://localhost:4200', // Corrected CORS origin
  optionsSuccessStatus: 200,
};

app.use(express.json());
app.use(cors(corsOptions));

mongoose.connect(conStr).then(() => {
  console.log("Connected With Atlas");
 
  app.get("/Advance/:AdvanceId",async (req,res)=>{
    const data = await advanceSchema.findOne({
        AdvanceId : req.params.AdvanceId
    });
    res.send(data);
});


app.patch('/UpdateAdvance/:AdvanceId',async(req,res)=>{
    const data = await advanceSchema.findOneAndUpdate({
        AdvanceId : req.params.AdvanceId
    },{
        ...req.body
    });
    res.send(data);
});

app.put('/UpdateAdvance/:AdvanceId',async(req,res)=>{
    const data = await advanceSchema.findOneAndUpdate({
        AdvanceId : req.params.AdvanceId
    },{
        ...req.body
    });
    res.send(data);
});


app.post('/AddAdvance',async(req,res)=>{
    const data = await advanceSchema.insertMany({
        ...req.body
    });
    res.send(data);
});

app.get('/getAllAdvanceWithEmloyeeDetails',async(req,res)=>{
    var data = await advanceSchema.find().lean();

    data = await Promise.all( data.map(async(d)=>{
        const employee = await empSchema.findOne({
            empId : d.empId
        }).lean();
        if(employee){
            d.employee =employee
        }
        return d;
    }))

   res.send(data);
});


app.delete('/DeleteAdvance/:AdvanceId',async (req,res)=>{
    const data = await advanceSchema.deleteOne({
        AdvanceId : req.params.AdvanceId
    })
    res.send(data);
})

  
});

app.listen(5004, () => {
  console.log("App Listening on Port 5004");
});
const express = require("express");
const mongoose = require("mongoose");
const attendanceSchema = require("./SchemaAttendance");
const empSchema = require("./dataSchema");
const cors = require('cors');

const app = express();
const conStr = "mongodb+srv://paresh_mori_67:Paresh%404577@paresh.xmqiuhh.mongodb.net/EmpDatabase";
const corsOptions = {
  origin: 'http://localhost:4200', // Corrected CORS origin
  optionsSuccessStatus: 200,
};

app.use(express.json());
app.use(cors(corsOptions));

mongoose.connect(conStr).then(() => {
  console.log("Connected With Atlas");


  app.get("/", async (req, res) => {
    try {
      const data = await attendanceSchema.find();
      res.json(data);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // Uncomment and complete these routes as needed
  
  app.post("/addAttendance", async (req, res) => {
    // const formData = {
    //   MeetingID: req.body.MeetingID,
    //   OrganizerName: req.body.OrganizerName,
    //   ParticipantName: req.body.ParticipantName,
    //   Date: req.body.Date,
    //   Time: req.body.Time,
    // };
    try {
      data = await attendanceSchema.insertMany({...req.body});
      res.send(data);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/:attendanceId", async (req, res) => {
    try {
      const data = await attendanceSchema.findOne({ attendanceId: req.params.attendanceId });
      res.json(data);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  app.delete("/:attendanceId", async (req, res) => {
    try {
      await attendanceSchema.deleteOne({ attendanceId : req.params.attendanceId });
      res.send("Delete successfully.... thank you");
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  app.put("/Edit_Attendance/:attendanceId", async (req, res) => {
    try {
      data = await attendanceSchema.findOneAndUpdate(
        { attendanceId: req.params.attendanceId },
        { ...req.body }
        // { MeetingID: req.params.MeetingID },
        // {
        //   $set: {
        //     MeetingID: req.body.MeetingID,
        //     OrganizerName: req.body.OrganizerName, 
        //     ParticipantName: req.body.ParticipantName,
        //     Date: req.body.Date,
        //     Time: req.body.Time
        //   }
        // }
      );
      res.send(data);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get('/getEmpWithAtd',async(req,res)=>{
    var data = await attendanceSchema.find().lean();
    data = await Promise.all(data.map(async(e)=>{
      const emp = await empSchema.findOne({empId:e.empId}).lean();
      if(emp){
        e.employee = emp
      }
      return e;
    }))
    res.send(data);
  });
  
});

app.listen(5001, () => {
  console.log("App Listening on Port 5001");
});

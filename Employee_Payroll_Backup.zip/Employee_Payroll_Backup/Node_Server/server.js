const express = require("express");
const mongoose = require("mongoose");
const empSchema = require("./dataSchema");
const leaveschema = require("./LeaveSchema");
const cors = require('cors');

const app = express();
const conStr = "mongodb+srv://paresh_mori_67:Paresh%404577@paresh.xmqiuhh.mongodb.net/EmpDatabase";
const corsOptions = {
  origin: 'http://localhost:4200', // Corrected CORS origin
  optionsSuccessStatus: 200,
};

app.use(express.json());
app.use(cors(corsOptions));

mongoose.connect(conStr).then(() => {
  console.log("Connected With Atlas");

  app.get("/", async (req, res) => {
    try {
      const data = await empSchema.find();
      res.json(data);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // Uncomment and complete these routes as needed
  
  app.post("/add", async (req, res) => {
    // const formData = {
    //   MeetingID: req.body.MeetingID,
    //   OrganizerName: req.body.OrganizerName,
    //   ParticipantName: req.body.ParticipantName,
    //   Date: req.body.Date,
    //   Time: req.body.Time,
    // };
    try {
      data = await empSchema.insertMany({...req.body});
      res.send(data);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/:empId", async (req, res) => {
    try {
      const data = await empSchema.findOne({ empId: req.params.empId });
      res.json(data);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  app.delete("/:empId", async (req, res) => {
    try {
      await empSchema.deleteOne({ empId : req.params.empId });
      res.send("Delete successfully.... thank you");
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  app.put("/:empId", async (req, res) => {
    try {
      data = await empSchema.updateOne(
        { empId: req.params.empId },
        { $set: req.body }
        // { MeetingID: req.params.MeetingID },
        // {
        //   $set: {
        //     MeetingID: req.body.MeetingID,
        //     OrganizerName: req.body.OrganizerName,
        //     ParticipantName: req.body.ParticipantName,
        //     Date: req.body.Date,
        //     Time: req.body.Time
        //   }
        // }
      );
      res.send(data);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });


  
});

app.listen(5000, () => {
  console.log("App Listening on Port 5000");
});

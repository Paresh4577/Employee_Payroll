const mongoose = require("mongoose");
const { double } = require("webidl-conversions");

const Schema = mongoose.Schema({
    empId: Number,
    empName: String,
    empContactNo: String,
    attendanceDate: String,
    attendanceId: Number,
    inTime: String,
    outTime: String,
    isFullDay: Boolean
  
});

module.exports = mongoose.model("attendanceSchema", Schema);
//{"_id":"66bcc2599d5ded4014f1cc2d","empId":44,"empName":"Hetanxi","empContactNo":"7867678","attendanceDate":"20-03-2008","attendanceId":2,"inTime":"9:00 AM","outTime":"9:00 PM","isFullDay":true},
//{"_id":"66bdefe5d30b90bbfe4dd04c","empId":122,"empName":"Paresh","empContactNo":"7867678","attendanceDate":"21-03-2008","attendanceId":2,"inTime":"10:00 AM","outTime":"9:00 PM","isFullDay":true,"__v":0}
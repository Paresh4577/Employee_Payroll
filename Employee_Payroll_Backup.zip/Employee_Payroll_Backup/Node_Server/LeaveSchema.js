const mongoose = require('mongoose');

const Schema = mongoose.Schema({
  "LeaveId": Number,
  "EmployeeId": Number,
  "LeaveDate": String,
  "LeaveReason": String,
  "NoOfFullDayLeaves": Number,
  "NoOfHalfDayLeaves": Number
});

module.exports = mongoose.model('LeaveSchema',Schema);
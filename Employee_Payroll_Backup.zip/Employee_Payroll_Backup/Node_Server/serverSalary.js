const express = require("express");
const mongoose = require("mongoose");
const salarySchema = require("./SalarySchema");
const empSchema = require("./dataSchema");
const cors = require('cors');

const app = express();
const conStr = "mongodb+srv://paresh_mori_67:Paresh%404577@paresh.xmqiuhh.mongodb.net/EmpDatabase";
const corsOptions = {
  origin: 'http://localhost:4200', // Corrected CORS origin
  optionsSuccessStatus: 200,
};

app.use(express.json());
app.use(cors(corsOptions));

mongoose.connect(conStr).then(() => {
  console.log("Connected With Atlas");

  app.get("/", async (req, res) => {
    try {
      const data = await salarySchema.find();
      res.json(data);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // Uncomment and complete these routes as needed
  
  app.post("/addSalary", async (req, res) => {
    // const formData = {
    //   MeetingID: req.body.MeetingID,
    //   OrganizerName: req.body.OrganizerName,
    //   ParticipantName: req.body.ParticipantName,
    //   Date: req.body.Date,
    //   Time: req.body.Time,
    // };
    try {
      data = await salarySchema.insertMany({...req.body});
      res.send(data);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/:salaryId", async (req, res) => {
    try {
      const data = await salarySchema.findOne({ salaryId: req.params.salaryId });
      res.json(data);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  app.delete("/:salaryId", async (req, res) => {
    try {
      await salarySchema.deleteOne({ salaryId : req.params.salaryId });
      res.send("Delete successfully.... thank you");
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  app.put("/Edit_Salary/:salaryId", async (req, res) => {
    try {
      data = await salarySchema.findOneAndUpdate(
        { salaryId: req.params.salaryId },
        { $set: req.body }
        // { MeetingID: req.params.MeetingID },
        // {
        //   $set: {
        //     MeetingID: req.body.MeetingID,
        //     OrganizerName: req.body.OrganizerName,
        //     ParticipantName: req.body.ParticipantName,
        //     Date: req.body.Date,
        //     Time: req.body.Time
        //   }
        // }
      );
      res.send(data);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get('/getAllSalaryWithEmloyeeDetails',async(req,res)=>{
    var data = await salarySchema.find().lean();

    data = await Promise.all( data.map(async(d)=>{
        const employee = await empSchema.findOne({
            empId : d.empId
        }).lean();
        if(employee){
            d.employee =employee
        }
        return d;
    }))

   res.send(data);
});
  
});

app.listen(5002, () => {
  console.log("App Listening on Port 5002");
});

const mongoose = require("mongoose");
const { double } = require("webidl-conversions");

const Schema = mongoose.Schema({
    "salaryId" : Number,
    "empId" : Number,
    "salaryDate" : Date,
    "totalAdvance" : Number,
    "presentDays": Number,
    "salaryAmount" : Number
  
});

module.exports = mongoose.model("salarySchema", Schema);

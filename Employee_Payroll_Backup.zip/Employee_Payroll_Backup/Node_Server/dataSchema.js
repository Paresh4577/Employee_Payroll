const mongoose = require("mongoose");
const { double } = require("webidl-conversions");

const Schema = mongoose.Schema({
    empId: Number,
    empName: String,
    empContactNo: String,
    empAltContactNo: String,
    empEmail: String,
    addressLine1: String,
    addressLine2: String,
    pincode: String,
    city: String,
    state: String,
    bankName: String,
    ifsc: String,
    accountNo: String,
    bankBranch: String,
    salary: Number
  
});

module.exports = mongoose.model("empSchema", Schema);

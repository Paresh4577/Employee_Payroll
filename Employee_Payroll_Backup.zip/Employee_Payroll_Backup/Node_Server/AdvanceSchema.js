const mongoose = require('mongoose');

const Schema = mongoose.Schema({
  "AdvanceId": Number,
  "empId": Number,
  "AdvanceDate": String,
  "AdvanceAmount": Number,
  "Reason": String
});

module.exports = mongoose.model('advanceSchema',Schema);
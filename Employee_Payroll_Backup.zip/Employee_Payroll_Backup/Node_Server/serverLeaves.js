  //Leaves
//   app.get("/allLeaves", async (req, res) => {
//     try {
//       const data = await leaveschema.find();
//       res.json(data);
//     } catch (err) {
//       res.status(500).json({ error: err.message });
//     }
//   });


//   app.get("/Leave/:LeaveId",async (req,res)=>{
//     const data = await LeaveTbl.findOne({
//         LeaveId : req.params.LeaveId
//     });
//     res.send(data);
// });


// app.patch('/UpdateLeave/:LeaveId',async(req,res)=>{
//     const data = await LeaveTbl.findOneAndUpdate({
//         LeaveId : req.params.LeaveId
//     },{
//         ...req.body
//     });
//     res.send(data);
// });

// app.put('/UpdateLeave/:LeaveId',async(req,res)=>{
//     const data = await LeaveTbl.findOneAndUpdate({
//         LeaveId : req.params.LeaveId
//     },{
//         ...req.body
//     });
//     res.send(data);
// });


// app.post('/AddLeave',async(req,res)=>{
//     const data = await LeaveTbl.insertMany({
//         ...req.body
//     });
//     res.send(data);
// });

// app.get('/getAllLeaveWithEmloyeeDetails',async(req,res)=>{
//     var data = await LeaveTbl.find().lean();

//     data = await Promise.all( data.map(async(d)=>{
//         const employee = await empSchema.findOne({
//             empId : d.EmployeeId 
//         }).lean();
//         if(employee){
//             d.employee =employee
//         }
//         return d;
//     }))

//    res.send(data);
// });


// app.delete('/DeleteLeave/:LeaveId',async (req,res)=>{
//     const data = await LeaveTbl.deleteOne({
//         LeaveId : req.params.LeaveId
//     })
//     res.send(data);
// })



const express = require("express");
const mongoose = require("mongoose");
const empSchema = require("./dataSchema");
const leaveschema = require("./LeaveSchema");
const cors = require('cors');

const app = express();
const conStr = "mongodb+srv://paresh_mori_67:Paresh%404577@paresh.xmqiuhh.mongodb.net/EmpDatabase";
const corsOptions = {
  origin: 'http://localhost:4200', // Corrected CORS origin
  optionsSuccessStatus: 200,
};

app.use(express.json());
app.use(cors(corsOptions));

mongoose.connect(conStr).then(() => {
  console.log("Connected With Atlas");

  app.get("/allLeaves", async (req, res) => {
    try {
      const data = await leaveschema.find();
      res.json(data);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

    app.get("/Leave/:LeaveId",async (req,res)=>{
    const data = await leaveschema.findOne({
        LeaveId : req.params.LeaveId
    });
    res.send(data);
});


app.patch('/UpdateLeave/:LeaveId',async(req,res)=>{
    const data = await leaveschema.findOneAndUpdate({
        LeaveId : req.params.LeaveId
    },{
        ...req.body
    });
    res.send(data);
});

app.put('/UpdateLeave/:LeaveId',async(req,res)=>{
    const data = await leaveschema.findOneAndUpdate({
        LeaveId : req.params.LeaveId
    },{
        ...req.body
    });
    res.send(data);
});


app.post('/AddLeave',async(req,res)=>{
    const data = await leaveschema.insertMany({
        ...req.body
    });
    res.send(data);
});

  app.get('/getAllLeaveWithEmloyeeDetails',async(req,res)=>{
    var data = await leaveschema.find().lean();

    data = await Promise.all( data.map(async(d)=>{
        const employee = await empSchema.findOne({
            empId : d.EmployeeId 
        }).lean();
        if(employee){
            d.employee =employee
        }
        return d;
    }))

   res.send(data);
});

app.delete('/DeleteLeave/:LeaveId',async (req,res)=>{
    const data = await leaveschema.deleteOne({
        LeaveId : req.params.LeaveId
    })
    res.send(data);
})


  
});

app.listen(5003, () => {
  console.log("App Listening on Port 5003");
});